# CONF

name = "Classei_Bridge_1"
title = "python3 base API client for shopware6"
version = "v2.0.7"
url = "https://github.com/bitranox/lib_shopware6_api_base"
author = "Robert Nowotny"
author_email = "bitranox@gmail.com"
shell_command = "Classei_Bridge_1"


def print_info() -> None:
    print(
        """\

Info for Classei_Bridge_1:

    python3 base API client for shopware6

    Version : v2.0.7
    Url     : https://github.com/bitranox/lib_shopware6_api_base
    Author  : Robert Nowotny
    Email   : bitranox@gmail.com"""
    )
