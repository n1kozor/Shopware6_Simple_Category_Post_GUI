import attrs
from attrs import validators


@attrs.define
class ConfSW6(object):
    shopware_admin_api_url: str = "http://localhost/api"
    shopware_storefront_api_url: str = "http://localhost/store-api"

    username: str = "admin"
    password: str = "shopware"


    client_id: str = ""
    client_secret: str = ""


    grant_type: str = "user_credentials"


    store_api_sw_access_key: str = ""

class ShopwareAPIError(BaseException):
    pass