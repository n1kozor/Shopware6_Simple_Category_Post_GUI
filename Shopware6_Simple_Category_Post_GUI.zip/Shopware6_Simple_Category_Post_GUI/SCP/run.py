from datetime import datetime
from SW6_uuid_generator import sw6_uuid
from api.sw6_api_base import Shopware6AdminAPIClientBase
from api.sw6_api_config import ConfSW6

import PySimpleGUI as sg


layout = [[sg.Text("Category name: ")],
          [sg.Input(key='c_name')],
          [sg.Text("Description: ")],
          [sg.Input(key='c_description')],
          [sg.Button('Ok'), sg.Button('Quit')]]


window = sg.Window('Simple Category Creator', layout)


while True:
    event, values = window.read()
    if event == "Ok":
        classei_conf = ConfSW6()
        classei_api_client = Shopware6AdminAPIClientBase(use_docker_test_container=True)
        classei_api_client = Shopware6AdminAPIClientBase(config=classei_conf)
        c_id = sw6_uuid()
        payload = {
            "id": "%s" % c_id,
            "name": "%s" % values['c_name'],
            "createdAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "displayNestedProducts": True,
            "productAssignmentType": "product",
            "type": "page",
            "description": '%s' % values['c_description'],
            "cmspageid": ''
        }
        classei_api_client.request_post("/category", payload)
    if event == sg.WINDOW_CLOSED or event == 'Quit':
        break


window.close()
