import uuid

def sw6_uuid(string_length=32):
    random = str(uuid.uuid4())
    random = random.replace("-", "")
    return random[0:string_length]

print(sw6_uuid(32))